function box2D(xmin,xmax,ymin,ymax,D,C)
% creates rectangular box where xmin<=x<=xmax, ymin<=y<=ymax, 
%    with D=true (solid), D=false (hole)
%
global Nx Ny d color
%
for i=1:Ny
    for j=1:Nx
        x=j;
        y=i;
        if x>=xmin & x<=xmax & y>=ymin & y<=ymax
            d(i,j)=D;
            color(i,j)=C;
        end
    end
end