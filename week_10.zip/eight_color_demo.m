clc; clear all; close all
%
global Nx Ny Nz d color
%
% Define design space
%
Nx=50;
Ny=50;
Nz=25;
%
% Initialize array variables
%
d=false(Ny,Nx,Nz);
color=char(zeros(Ny,Nx,Nz));
%
% Build geometry
%
box( 3,47, 3,47,1,1,true,'k');
box( 4,46, 4,46,1,2,true,'k');
box( 5,45, 5,45,1,3,true,'k');
box( 6,44, 6,44,1,4,true,'g');
box( 7,43, 7,43,1,5,true,'g');
box( 8,42, 8,42,1,6,true,'g');
box( 9,41, 9,41,1,7,true,'b');
box(10,40,10,40,1,8,true,'b');
box(11,39,11,39,1,9,true,'b');
box(12,38,12,38,1,10,true,'y');
box(13,37,13,37,1,11,true,'y');
box(14,36,14,36,1,12,true,'y');
box(15,35,15,35,1,13,true,'m');
box(16,34,16,34,1,14,true,'m');
box(17,33,17,33,1,15,true,'m');
box(18,32,18,32,1,16,true,'r');
box(19,31,19,31,1,17,true,'r');
box(20,30,20,30,1,18,true,'r');
box(21,29,21,29,1,19,true,'c');
box(22,28,22,28,1,20,true,'c');
box(23,27,23,27,1,21,true,'c');
box(24,26,24,26,1,22,true,'w');
box(25,25,25,25,1,23,true,'w');
%
% Preview geometry
%
preview
%
% Create 3D model
%
model_gen
movefile('model.obj','eight_color_demo.obj')
%
% Create animation
%
model_animate
movefile('model.gif','eight_color_demo.gif')

