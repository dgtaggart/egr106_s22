function box_demo_2
%
clc; clear all; close all
%
global Nx Ny d color
%
% define design domain (use Nx=20, Ny=30)
%
Nx=20;
Ny=30;
%
% initialize arrays 'd' and 'color' (Ny rows x Nx columns)
%
d=false(Ny,Nx);
color=char(zeros(Ny,Nx));
%
% create blue rectangular box with 2<=x<=18, 2<=y<=28
box2D(2,18,2,28,true,'b')
% create red rectangular box with 5<=x<=15, 7<=y<=20
box2D(5,15,7,20,true,'r')
% create rectangular hole with 8<=x<=12, 10<=y<=15
box2D(8,12,10,15,false,'r')
% 
% display result
%
for i=1:Ny
    for j=1:Nx
        x=j;
        y=i;
        if d(i,j)==true
            marker=[color(i,j) '*'];
            plot(x,y,marker)
            hold on
        end
    end
end
axis([0 30 0 30])
d
color

%
% -------------------------------------------------------
%
function box2D(xmin,xmax,ymin,ymax,D,C)
% creates rectangular where xmin<=x<=xmax, ymin<=y<=ymax, 
%    with D=true (solid), D=false (hole)
%
global Nx Ny d color
%
for i=1:Ny
    for j=1:Nx
        x=j;
        y=i;
        if x>=xmin & x<=xmax & y>=ymin & y<=ymax
            d(i,j)=D;
            color(i,j)=C;
        end
    end
end
