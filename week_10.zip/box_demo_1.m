function box_demo_1
%
clc; clear all; close all
%
global Nx Ny d color
%
% define design domain (use Nx=10, Ny=20)
%
Nx=10;
Ny=20;
%
% initialize arrays 'd' and 'color' (Ny rows x Nx columns)
%
d=false(Ny,Nx);
color=char(zeros(Ny,Nx));
%
% create blue rectangular box with 3<=x<=5, 3<=y<=15
box2D(3,5,3,15,true,'b')
% 
% display result
%
for i=1:Ny
    for j=1:Nx
        x=j;
        y=i;
        if d(i,j)==true
            marker=[color(i,j) '*'];
            plot(x,y,marker)
            hold on
        end
    end
end
axis([0 30 0 30])
d
color

%
% -------------------------------------------------------
%
function box2D(xmin,xmax,ymin,ymax,D,C)
% creates rectangular where xmin<=x<=xmax, ymin<=y<=ymax, 
%    with D=true (solid), D=false (hole)
%
global Nx Ny d color
%
for i=1:Ny
    for j=1:Nx
        x=j;
        y=i;
        if x>=xmin & x<=xmax & y>=ymin & y<=ymax
            d(i,j)=D;
            color(i,j)=C;
        end
    end
end
