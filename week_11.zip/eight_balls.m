function eight_balls
%
clc; clear; close all;
%
global Nx Ny Nz d color
%
% Define design space
%
Nx=50;
Ny=50;
Nz=50;
%
% Initialize array variables
%
d=false(Ny,Nx,Nz);
color=char(zeros(Ny,Nx,Nz));
%
% Build geometry
%
sphere(.25*Nx,.25*Nx,.25*Nx,.15*Nx,true,'r');
sphere(.25*Nx,.25*Nx,.75*Nx,.15*Nx,true,'g');
sphere(.25*Nx,.75*Nx,.25*Nx,.15*Nx,true,'b');
sphere(.25*Nx,.75*Nx,.75*Nx,.15*Nx,true,'y');
sphere(.75*Nx,.25*Nx,.25*Nx,.15*Nx,true,'m');
sphere(.75*Nx,.25*Nx,.75*Nx,.15*Nx,true,'c');
sphere(.75*Nx,.75*Nx,.25*Nx,.15*Nx,true,'k');
sphere(.75*Nx,.75*Nx,.75*Nx,.15*Nx,true,'w');
%
% Preview geometry
%
preview
%
% Create 3D model
%
model_gen
movefile('model.obj','eight_balls.obj')
%
% Create animation
%
model_animate
movefile('model.gif','eight_balls.gif')

