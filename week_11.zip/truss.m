%
% Sample program - truss.m
%
clc; clear all; close all; format compact; format short
%
global Nx Ny Nz d color
%
Nx=150;
Ny=30;
Nz=30;
%
% cp=0;
% cp=[]
d=false(Ny,Nx,Nz);
color=char(zeros(Ny,Nx,Nz));
%
x1=.1*Nx;
x2=.2*Nx;
x3=.3*Nx;
x4=.4*Nx;
x5=.5*Nx;
x6=.6*Nx;
x7=.7*Nx;
x8=.8*Nx;
x9=.9*Nx;
%
y1=.1*Ny;
y2=.9*Ny;
%
z1=.1*Nz;
z2=.9*Nz;
%
R=1.5;
%
% top members (green)
%
segment([x2 y1 z2],[x4 y1 z2],R,true,'g')
segment([x4 y1 z2],[x6 y1 z2],R,true,'g')
segment([x6 y1 z2],[x8 y1 z2],R,true,'g')
%
segment([x2 y2 z2],[x4 y2 z2],R,true,'g')
segment([x4 y2 z2],[x6 y2 z2],R,true,'g')
segment([x6 y2 z2],[x8 y2 z2],R,true,'g')
%
% Side truss members (red)
%
segment([x1 y1 z1],[x2 y1 z2],R,true,'r')
segment([x2 y1 z2],[x3 y1 z1],R,true,'r')
segment([x3 y1 z1],[x4 y1 z2],R,true,'r')
segment([x4 y1 z2],[x5 y1 z1],R,true,'r')
segment([x5 y1 z1],[x6 y1 z2],R,true,'r')
segment([x6 y1 z2],[x7 y1 z1],R,true,'r')
segment([x7 y1 z1],[x8 y1 z2],R,true,'r')
segment([x8 y1 z2],[x9 y1 z1],R,true,'r')
%
segment([x1 y2 z1],[x2 y2 z2],R,true,'r')
segment([x2 y2 z2],[x3 y2 z1],R,true,'r')
segment([x3 y2 z1],[x4 y2 z2],R,true,'r')
segment([x4 y2 z2],[x5 y2 z1],R,true,'r')
segment([x5 y2 z1],[x6 y2 z2],R,true,'r')
segment([x6 y2 z2],[x7 y2 z1],R,true,'r')
segment([x7 y2 z1],[x8 y2 z2],R,true,'r')
segment([x8 y2 z2],[x9 y2 z1],R,true,'r')
%
% Cross bars (yellow)
%
segment([x2 y1 z2],[x2 y2 z2],R,true,'y')
segment([x4 y1 z2],[x4 y2 z2],R,true,'y')
segment([x6 y1 z2],[x6 y2 z2],R,true,'y')
segment([x8 y1 z2],[x8 y2 z2],R,true,'y')
%
% Road surface (blue)
%
box(x1-1,x9+1,y1-1,y2+1,z1-1,z1+1,true,'b')
%
% Preview design
%
preview
%
% Create 3D model
% 
model_gen
movefile('model.obj','truss.obj')
% %
% % Create animation
% %
model_animate
movefile('model.gif','truss.gif')
%


