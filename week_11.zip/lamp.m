function lamp
%
clc; clear; close all
%
global Nx Ny Nz d color
%
% Define design space
%
Nx=50;
Ny=50;
Nz=50;
%
% Initialize array variables
%
d=false(Ny,Nx,Nz);
color=char(zeros(Ny,Nx,Nz));
%
% Build geometry
%
cylinder_z(.5*Nx,.5*Ny,.50*Nz,.55*Nz,.48*Nx,true,'r');
cylinder_z(.5*Nx,.5*Ny,.50*Nz,.55*Nz,.40*Nx,false,'r');
cylinder_z(.5*Nx,.5*Ny,.55*Nz,.60*Nz,.45*Nx,true,'r');
cylinder_z(.5*Nx,.5*Ny,.55*Nz,.60*Nz,.35*Nx,false,'r');
cylinder_z(.5*Nx,.5*Ny,.60*Nz,.65*Nz,.40*Nx,true,'r');
cylinder_z(.5*Nx,.5*Ny,.60*Nz,.65*Nz,.30*Nx,false,'r');
%
cylinder_z(.5*Nx,.5*Ny,.65*Nz,.70*Nz,.35*Nx,true,'g');
cylinder_z(.5*Nx,.5*Ny,.65*Nz,.70*Nz,.25*Nx,false,'g');
cylinder_z(.5*Nx,.5*Ny,.70*Nz,.75*Nz,.30*Nx,true,'g');
cylinder_z(.5*Nx,.5*Ny,.70*Nz,.75*Nz,.20*Nx,false,'g');
cylinder_z(.5*Nx,.5*Ny,.75*Nz,.80*Nz,.25*Nx,true,'g');
cylinder_z(.5*Nx,.5*Ny,.70*Nz,.80*Nz,.15*Nx,false,'g');
%
cylinder_z(.5*Nx,.5*Ny,.75*Nz,.85*Nz,.20*Nx,true,'b');
cylinder_z(.5*Nx,.5*Ny,.75*Nz,.85*Nz,.10*Nx,false,'b');
cylinder_z(.5*Nx,.5*Ny,.85*Nz,.90*Nz,.15*Nx,true,'b');
cylinder_z(.5*Nx,.5*Ny,.85*Nz,.90*Nz,.05*Nx,false,'b');
%
cylinder_z(.5*Nx,.5*Ny,.90*Nz,.95*Nz,.10*Nx,true,'m');
cylinder_z(.5*Nx,.5*Ny,.00*Nz,.05*Nz,.10*Nx,true,'m');
cylinder_z(.5*Nx,.5*Ny,.05*Nz,.10*Nz,.12*Nx,true,'m');
cylinder_z(.5*Nx,.5*Ny,.10*Nz,.15*Nz,.14*Nx,true,'m');
cylinder_z(.5*Nx,.5*Ny,.15*Nz,.20*Nz,.14*Nx,true,'y');
cylinder_z(.5*Nx,.5*Ny,.20*Nz,.25*Nz,.12*Nx,true,'y');
cylinder_z(.5*Nx,.5*Ny,.25*Nz,.30*Nz,.10*Nx,true,'y');
cylinder_z(.5*Nx,.5*Ny,.30*Nz,.35*Nz,.10*Nx,true,'c');
cylinder_z(.5*Nx,.5*Ny,.35*Nz,.40*Nz,.12*Nx,true,'c');
cylinder_z(.5*Nx,.5*Ny,.40*Nz,.45*Nz,.14*Nx,true,'c');
cylinder_z(.5*Nx,.5*Ny,.45*Nz,.50*Nz,.14*Nx,true,'g');
cylinder_z(.5*Nx,.5*Ny,.50*Nz,.55*Nz,.12*Nx,true,'g');
cylinder_z(.5*Nx,.5*Ny,.55*Nz,.60*Nz,.10*Nx,true,'g');
cylinder_z(.5*Nx,.5*Ny,.60*Nz,.65*Nz,.10*Nx,true,'b');
cylinder_z(.5*Nx,.5*Ny,.65*Nz,.70*Nz,.12*Nx,true,'b');
cylinder_z(.5*Nx,.5*Ny,.70*Nz,.75*Nz,.14*Nx,true,'b');
cylinder_z(.5*Nx,.5*Ny,.75*Nz,.80*Nz,.14*Nx,true,'k');
cylinder_z(.5*Nx,.5*Ny,.80*Nz,.85*Nz,.12*Nx,true,'k');
cylinder_z(.5*Nx,.5*Ny,.85*Nz,.90*Nz,.10*Nx,true,'k');
%
% Preview geometry
%
preview
%
% Create 3D model
%
model_gen
movefile('model.obj','lamp.obj')
%
% Create animation
%
model_animate
movefile('model.gif','lamp.gif')


